# LBSHS-LMS
A Library Management System Software. Used at Labone Senior High
