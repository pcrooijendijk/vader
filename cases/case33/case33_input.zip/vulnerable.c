#include <string.h>

void process_input(const char* input, int length) {
    char buffer[16];
    // Vulnerable: No bounds checking
    memcpy(buffer, input, length);
}