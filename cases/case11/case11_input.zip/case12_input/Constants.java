package foo.core;

/**
 * jeecore 常量
 * 
 * @author liufang
 * 
 */
public class Constants {
}
