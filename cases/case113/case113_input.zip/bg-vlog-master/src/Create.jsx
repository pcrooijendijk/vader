
// import Home from "./Home";
function create() {
  return (
    <div  className='Create'>
        <h2>add new vlog</h2>
    </div>
  )
}

export default create;
