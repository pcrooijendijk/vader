import React from "react";
import Layout from "../components/Layout";

const Privacy = () => {
  return (
    <div>
      <Layout title={"Deep Known - Privacy & Policy"}></Layout>
    </div>
  );
};

export default Privacy;
