import React from "react";
import Layout from "../components/Layout";

const NewMovies = () => {
  return (
    <div>
      <Layout title={"new movies"}>new Movies</Layout>
    </div>
  );
};

export default NewMovies;
