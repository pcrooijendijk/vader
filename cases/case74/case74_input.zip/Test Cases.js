const request = require('supertest');
const express = require('express');
const cookieParser = require('cookie-parser');
const csurf = require('csurf');

const app = express();
app.use(cookieParser());
app.use(express.urlencoded({ extended: true }));
app.use(csurf({ cookie: true }));

app.get('/csrf-token', (req, res) => {
  res.json({ csrfToken: req.csrfToken() });
});

app.post('/secure-action', (req, res) => {
  res.json({ message: "Acción realizada con protección CSRF." });
});

describe('CSRF Protection', () => {
  let csrfToken;

  it('Debe obtener un token CSRF', async () => {
    const res = await request(app).get('/csrf-token');
    expect(res.body.csrfToken).toBeDefined();
    csrfToken = res.body.csrfToken;
  });

  it('Debe rechazar una solicitud sin token CSRF', async () => {
    const res = await request(app).post('/secure-action');
    expect(res.status).toBe(403);
  });

  it('Debe aceptar una solicitud con un token CSRF válido', async () => {
    const agent = request.agent(app);
    await agent.get('/csrf-token');
    const res = await agent.post('/secure-action').send({ _csrf: csrfToken });
    expect(res.status).toBe(200);
    expect(res.body.message).toBe("Acción realizada con protección CSRF.");
  });
});
