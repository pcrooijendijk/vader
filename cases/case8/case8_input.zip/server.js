
const express = require('express');
const fs = require('fs');
const app = express();
const port = 3000;

app.get('/get-project-files', (req, res) => {
    const projectName = req.query['project-name'];
    const filePath = `./projects/${projectName}`;

    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) return res.status(500).send('Error reading file');
        res.send(data);
    });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
