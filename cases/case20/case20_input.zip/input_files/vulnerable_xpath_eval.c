#include <libxml/parser.h>
#include <libxml/xpath.h>

void vulnerable_xpath_eval(xmlDocPtr doc, xmlNodePtr node) {
    xmlXPathContextPtr ctxt;
    ctxt = xmlXPathNewContext(doc);
    ctxt->node = node; // Potential NULL dereference if ctxt == NULL
}