
// Simulated vulnerable code in Gogs
package main

import (
    "os/exec"
)

func runGitCommand(args []string) error {
    cmd := exec.Command("git", args...)
    return cmd.Run()
}
