
// Simulated vulnerable log use
void log_user_input(const char *user_input) {
    ns_log(Error, "User input: %s", user_input);
}
