import React from "react";

const AudioPlayer = () => {
  return <div>AudioPlayer</div>;
};

export default AudioPlayer;
