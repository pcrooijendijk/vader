import React from "react";

const GetMusicData = () => {
  return <div>GetMusicData</div>;
};

export default GetMusicData;
