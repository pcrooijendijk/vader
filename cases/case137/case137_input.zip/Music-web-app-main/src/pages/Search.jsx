import React from "react";
import Layout from "../components/Layout";

const Search = () => {
  return (
    <div>
      <Layout>Search</Layout>
    </div>
  );
};

export default Search;
