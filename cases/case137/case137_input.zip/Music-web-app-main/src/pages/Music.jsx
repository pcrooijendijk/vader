import React from "react";
import Layout from "../components/Layout";

const Music = () => {
  return (
    <div>
      <Layout>Music</Layout>
    </div>
  );
};

export default Music;
