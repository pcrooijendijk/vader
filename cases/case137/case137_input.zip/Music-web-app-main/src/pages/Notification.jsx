import React from "react";
import Layout from "../components/Layout";

const Notification = () => {
  return (
    <div>
      <Layout>Notification</Layout>
    </div>
  );
};

export default Notification;
