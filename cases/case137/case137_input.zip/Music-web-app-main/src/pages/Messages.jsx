import React from "react";
import Layout from "../components/Layout";

const Messages = () => {
  return (
    <div>
      <Layout>Messages</Layout>
    </div>
  );
};

export default Messages;
