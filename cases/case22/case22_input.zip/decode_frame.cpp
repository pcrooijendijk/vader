#include <emscripten.h>
#include <stdint.h>

extern "C" {
    EMSCRIPTEN_KEEPALIVE
    void decode_frame(uint8_t* data, int len) {
        // Unsafe access simulation (e.g., unbounded access)
        uint8_t buffer[16];
        for (int i = 0; i < len; ++i) {
            buffer[i] = data[i]; // No bounds check
        }
    }
}