import { useMemo } from 'react'

// TODO: remove or fix
export function useRedirect() {
  return useMemo(() => '/', [])
}