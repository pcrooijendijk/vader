#include <emscripten.h>
#include <cstring>

char buffer[16];

extern "C" {
    EMSCRIPTEN_KEEPALIVE
    void writeToBuffer(const char* input, int len) {
        // No bounds checking — classic overflow
        memcpy(buffer, input, len);
    }
}