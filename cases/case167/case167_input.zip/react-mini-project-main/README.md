The repo consists of code written for a small project- Weather App built using React and API.
